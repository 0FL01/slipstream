#!/bin/sh
# Restore only this experiment; never reload or flush the shared ruleset.
set -eu
umask 077
b=/root/backups/ru-de-slipstream-five-20261030T203650Z
w=/run/slipstream-mp-bench
sha256sum --check "$b/protected.sha256" >/dev/null
test -f /run/systemd/system/flowd.service.d/90-ru-de-bench.conf
test -f /run/systemd/system/slipstream.service.d/90-ru-de-bench.conf
rm /run/systemd/system/flowd.service.d/90-ru-de-bench.conf
rm /run/systemd/system/slipstream.service.d/90-ru-de-bench.conf
rmdir /run/systemd/system/flowd.service.d 2>/dev/null || :
rmdir /run/systemd/system/slipstream.service.d 2>/dev/null || :
systemctl daemon-reload
systemd-analyze verify /etc/systemd/system/flowd.service /etc/systemd/system/slipstream.service
systemctl restart flowd.service slipstream.service
test "$(readlink /proc/$(systemctl show -p MainPID --value slipstream.service)/exe)" = /usr/local/bin/slipstream-server
python3 - <<'PY'
import socket,time
for attempt in range(100):
    try:
        sock=socket.create_connection(('10.200.0.2',40001),.2)
        sock.close()
        break
    except OSError:
        time.sleep(.1)
else:
    raise SystemExit('restored production listener unavailable')
PY
python3 -B "$w/flowd_probe.py" > "$w/restored-proof.jsonl"
cat "$w/restored-proof.jsonl"
systemctl stop slipstream-mp-direct.service slipstream-mp-fixture.service
python3 - <<'PY'
import json,subprocess
state=json.loads(subprocess.check_output(['nft','-j','-a','list','chain','inet','firewall','filter_input']))
rules=[item['rule'] for item in state['nftables'] if 'rule' in item and
       item['rule'].get('comment')=='ru-de-slipstream-five']
assert len(rules)==1, 'owned input rule identity mismatch'
subprocess.run(['nft','delete','rule','inet','firewall','filter_input','handle',str(rules[0]['handle'])],check=True)
PY
rm /run/systemd/system/slipstream-mp-direct.service /run/systemd/system/slipstream-mp-fixture.service
systemctl daemon-reload
test "$(sha256sum /usr/local/bin/flowd-ru-de-bench | cut -d ' ' -f 1)" = 18588aed884fc48ab7d8ab0761d64e9e817fcfed085359cb6571bfd0ccc412a2
rm /usr/local/bin/flowd-ru-de-bench
cmp -s /usr/local/bin/slipstream-server-mp5 "$w/slipstream-server"
rm /usr/local/bin/slipstream-server-mp5
sha256sum --check "$b/protected.sha256" >/dev/null
nft --check --file /etc/nftables.conf
nft -s list ruleset > "$w/final-runtime-stateless.nft"
cmp -s "$b/runtime-stateless.nft" "$w/final-runtime-stateless.nft"
systemctl show flowd.service slipstream.service warp-svc-netns.service --property=Id,MainPID,ActiveState,SubState,NRestarts,ActiveEnterTimestamp,StandardOutput,StandardError,DropInPaths > "$w/final-service-state"
cat "$w/final-service-state"
printf 'RESTORED: original nine files and complete stateless runtime rules match backup; temporary services/rule/binary removed\n'
