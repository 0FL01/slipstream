"""Finite requested five-resolver trial, reusing the existing owned workload."""
import asyncio
import json
import time

import matrix
import pool

RESOLVERS = ['8.8.8.8', '1.1.1.1', '9.9.9.9', '208.67.222.222', '223.5.5.5']


async def main():
    deadline = time.time() + 1800
    pool.POOL = RESOLVERS
    experiment = dict(resolvers=RESOLVERS, workers=224, queue=64,
                      original_deadline=deadline, control=None, screen=None, confirmation=None)
    decision = matrix.ROOT / 'five-decision.json'
    decision.write_text(json.dumps(experiment, indent=2))
    await pool.main()
    singles = [row for row in matrix.read_rows(pool.ROOT / 'pool.jsonl')
               if row['kind'] == 'pool-summary' and row['ok'] and row['index'] < len(RESOLVERS)]
    if not singles:
        experiment['reason'] = 'No requested resolver completed the real-payload screen; no usable control.'
        decision.write_text(json.dumps(experiment, indent=2))
        raise SystemExit(experiment['reason'])
    best = max(singles, key=lambda row: row['download_Bps'])
    matrix.SINGLE = [RESOLVERS[best['index']]]
    experiment['control'] = matrix.SINGLE
    decision.write_text(json.dumps(experiment, indent=2))
    print(json.dumps(dict(kind='five-control-selected', resolver=matrix.SINGLE[0],
                          deadline=deadline)), flush=True)
    screen = await matrix.compare('five-224', RESOLVERS, 224, 'screen', 2)
    experiment['screen'] = screen
    rows = matrix.read_rows(matrix.ROOT / 'five-224-screen.jsonl')
    cleanup = [row for row in rows if row['kind'] == 'cleanup' and row['arm'] == 'B']
    responsive = [sum(path['replies'] > 0 for path in row['adapter']) for row in cleanup]
    experiment['candidate_responsive_dns_adapters'] = responsive
    experiment['reason'] = 'No complete five-way candidate won both matched DL screening pairs.'
    decision.write_text(json.dumps(experiment, indent=2))
    if screen['credible'] and len(responsive) == 2 and all(count == 5 for count in responsive):
        durations = [row['seconds'] for row in rows if row['kind'] == 'window' and row['ok']]
        if deadline - time.time() > 12 * max(durations, default=90) + 60:
            experiment['confirmation'] = await matrix.compare('five-224', RESOLVERS, 224, 'confirm', 6)
            experiment['reason'] = 'Fresh six-pair confirmation after both five-way screening wins.'
        else:
            experiment['reason'] = 'Promising screen but insufficient fixed budget for six fresh pairs; unconfirmed.'
    elif screen['credible']:
        experiment['reason'] = 'DL screen won, but not all five DNS adapters responded in both windows; not a proven five-way candidate.'
    decision.write_text(json.dumps(experiment, indent=2))
    print(json.dumps(dict(kind='five-trial-complete', responsive_dns_adapters=responsive,
                          confirmation=experiment['confirmation'] is not None,
                          reason=experiment['reason'])), flush=True)


if __name__ == '__main__':
    asyncio.run(main())
