"""Frozen finite RU-DE experiment; uses the existing workload and cleanup owner."""
import asyncio
import json
from pathlib import Path
from statistics import median

import run
from summarize import summarize

ROOT = Path(__file__).resolve().parent
SINGLE = ['8.8.8.8']
CASES = [('gg', ['8.8.8.8', '8.8.4.4']),
         ('gy', ['8.8.8.8', '77.88.8.8']),
         ('ggy', ['8.8.8.8', '8.8.4.4', '77.88.8.8'])]


def read_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


async def compare(label, endpoints, workers, phase, pairs):
    path = ROOT / (label + '-' + phase + '.jsonl')
    if path.exists():
        raise FileExistsError('experiment labels are exclusive')
    campaign = 'ru-de-' + label
    for pair in range(pairs):
        for position, arm in enumerate(('A', 'B') if pair % 2 == 0 else ('B', 'A')):
            current = SINGLE if arm == 'A' else endpoints
            profile = ('single' if arm == 'A' else label) + '-' + str(workers)
            argv = ['--variant', 'C1', '--server', profile, '--results', str(path),
                '--credentials', str(ROOT / 'credentials.json'), '--cert', str(ROOT / 'server.crt'),
                '--binary', str(ROOT / 'slipstream-client'), '--execution', 'native',
                '--carrier', 'multipath', '--tcp-workers', str(workers),
                '--backend', 'https', '--target-host', '195.128.101.186', '--target-port', '40004',
                '--fixture-cert', str(ROOT / 'fixture.crt'), '--egress', 'direct',
                '--deadline', '60', '--startup-deadline', '15', '--campaign', campaign,
                '--phase', phase, '--pair', str(pair), '--position', str(position), '--arm', arm]
            for host in current:
                argv += ['--tcp-resolver', host + ':53']
            ok = await run.main(run.arguments(argv), run.protected_json(str(ROOT / 'credentials.json')))
            rows = [row for row in read_rows(path) if row['pair'] == pair and row['arm'] == arm]
            requests = [row for row in rows if row['kind'] == 'request']
            dl = next(row for row in requests if row['condition'] == 'sequential' and row['opcode'] == 'D')
            ul = next(row for row in requests if row['condition'] == 'sequential' and row['opcode'] == 'U' and row['requested'] == 524288)
            print(json.dumps(dict(kind='matrix-window', label=label, phase=phase, pair=pair,
                                  arm=arm, workers=workers, paths=len(current), ok=ok,
                                  download_Bps=dl['ack_Bps'], upload512_Bps=ul['ack_Bps'])), flush=True)
    rows = read_rows(path)
    report = summarize(rows, 'sequential:D:1048576')
    (ROOT / (label + '-' + phase + '-report.json')).write_text(json.dumps(report, indent=2))
    primary = [row for row in rows if row['kind'] == 'request' and
               row['condition'] == 'sequential' and row['opcode'] == 'D']
    candidate_dl = median(row['ack_Bps'] for row in primary if row['arm'] == 'B')
    control_dl = median(row['ack_Bps'] for row in primary if row['arm'] == 'A')
    failed = sum(not row['ok'] for row in rows if row['kind'] == 'window')
    ratios = [row['ratio_B_over_A'] for row in report['pairs']]
    result = dict(kind='case-summary', label=label, phase=phase, endpoints=endpoints,
                  workers=workers, candidate_download_Bps=candidate_dl, single_download_Bps=control_dl,
                  paired_ratios=ratios, failed_windows=failed,
                  credible=failed == 0 and len(ratios) == pairs and all(r is not None and r > 1 for r in ratios))
    # Public resolver choices are experiment configuration, not retained traffic destinations.
    print(json.dumps(result), flush=True)
    return result


async def main():
    cases = []
    for label, endpoints in CASES:
        cases.append(await compare(label + '-56', endpoints, 56, 'screen', 2))
    working = [case for case in cases if case['failed_windows'] == 0]
    best = max(working or cases, key=lambda case: case['candidate_download_Bps'])
    for workers in (112, 224):
        cases.append(await compare('scaled-' + str(workers), best['endpoints'], workers, 'screen', 2))
    credible = [case for case in cases if case['credible']]
    confirmation = None
    if credible:
        selected = max(credible, key=lambda case: case['candidate_download_Bps'])
        confirmation = await compare('selected-' + selected['label'], selected['endpoints'],
                                     selected['workers'], 'confirm', 6)
    decision = dict(cases=cases, confirmation=confirmation,
                    reason='Fresh confirmation for the fastest complete consistently winning screen.'
                    if confirmation else 'No complete multipath candidate won both matched screening pairs.')
    (ROOT / 'decision.json').write_text(json.dumps(decision, indent=2))
    print(json.dumps(dict(kind='matrix-complete', confirmation=confirmation is not None)), flush=True)


if __name__ == '__main__':
    asyncio.run(main())
