"""One bounded, sequential synthetic resolver screen; not a background ranker."""
import asyncio
import hashlib
import json
from pathlib import Path
import time

from run import Results, Runner, arguments, carrier_manifest, protected_json

ROOT = Path(__file__).resolve().parent
POOL = ['77.88.8.88', '77.88.8.1', '77.88.8.8', '1.1.1.1',
        '1.0.0.1', '8.8.8.8', '8.8.4.4', '9.9.9.9']


async def sample(index, host):
    label = 'resolver-' + str(index)
    args = arguments(['--variant', 'C1', '--server', label, '--results', str(ROOT / 'pool.jsonl'),
        '--credentials', str(ROOT / 'credentials.json'), '--cert', str(ROOT / 'server.crt'),
        '--binary', str(ROOT / 'slipstream-client'), '--execution', 'native',
        '--carrier', 'multipath', '--tcp-resolver', host + ':53', '--tcp-workers', '56',
        '--backend', 'https', '--target-host', '195.128.101.186', '--target-port', '40004',
        '--fixture-cert', str(ROOT / 'fixture.crt'), '--egress', 'direct',
        '--deadline', '20', '--startup-deadline', '15', '--campaign', 'ru-de-pool'])
    metadata = dict(version=1, variant='C1', server=label, campaign='ru-de-pool', phase='screen',
                    pair=index, position=0, arm='A', sample=0, carrier='multipath', backend='https')
    output = Results(args.results, metadata)
    runner = Runner(args, protected_json(args.credentials), output)
    started = time.monotonic()
    try:
        output.emit(dict(kind='manifest', cc='dcubic', deadline=20, startup_deadline=15,
            client_sha256=hashlib.sha256(Path(args.binary).read_bytes()).hexdigest(),
            script_sha256=hashlib.sha256((ROOT / 'run.py').read_bytes()).hexdigest(),
            adapter_sha256=hashlib.sha256((ROOT / 'adapter.py').read_bytes()).hexdigest(),
            driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            sizes=[32768], download=524288, **carrier_manifest(args)))
        await runner.start()
        download = await runner.request('D', 524288, 'pool')
        upload = await runner.request('U', 32768, 'pool')
        snapshot = runner.snapshot()
        result = dict(kind='pool-summary', index=index, ok=download['ok'] and upload['ok'],
                      download_Bps=download['ack_Bps'], upload_Bps=upload['ack_Bps'],
                      failures=int(not download['ok']) + int(not upload['ok']),
                      seconds=time.monotonic() - started, adapter=snapshot['adapter'])
    except (OSError, ValueError, KeyError, EOFError, TimeoutError) as error:
        result = dict(kind='pool-summary', index=index, ok=False, download_Bps=0, upload_Bps=0,
                      failures=1, seconds=time.monotonic() - started, error=type(error).__name__)
    finally:
        await runner.cleanup()
    output.emit(result)
    output.output.close()
    print(json.dumps(result), flush=True)


async def main():
    owner = asyncio.current_task()
    import signal
    asyncio.get_running_loop().add_signal_handler(signal.SIGTERM, owner.cancel)
    for index, host in enumerate(POOL):
        await sample(index, host)


if __name__ == '__main__':
    asyncio.run(main())
