"""Ephemeral synthetic checks of the existing private FlowRelay boundary."""
import argparse
import hashlib
import http.client
import ipaddress
import json
from pathlib import Path
import secrets
import socket
import ssl
import struct
import subprocess

ROOT = Path('/run/slipstream-mp-bench')
SERVER = ('10.200.0.2', 40001)
STUN = ('162.159.207.0', 3478)
DIRECT = '195.128.101.186'


def exact(sock, size):
    result = b''
    while len(result) < size:
        chunk = sock.recv(size - len(result))
        if not chunk:
            raise EOFError('closed before exact response')
        result += chunk
    return result


def stun_ip(packet, transaction):
    assert packet[:2] == bytes([1, 1]) and packet[4:8] == struct.pack('!I', 0x2112A442)
    assert packet[8:20] == transaction and len(packet) == 20 + struct.unpack('!H', packet[2:4])[0]
    offset = 20
    while offset + 4 <= len(packet):
        kind, size = struct.unpack('!HH', packet[offset:offset + 4])
        value = packet[offset + 4:offset + 4 + size]
        if kind == 0x0020 and size == 8 and value[1] == 1:
            return str(ipaddress.IPv4Address(struct.unpack('!I', value[4:8])[0] ^ 0x2112A442))
        offset += 4 + (size + 3) // 4 * 4
    raise ValueError('no IPv4 XOR-MAPPED-ADDRESS')


def fingerprint(address):
    return hashlib.sha256(address.encode()).hexdigest()[:12]


def open_flow(token, destination=('1.1.1.1', 443), udp=False):
    sock = socket.create_connection(SERVER, 10)
    sock.settimeout(15)
    sock.sendall(bytes([0x28 if udp else 0x20]) + token +
                 ipaddress.IPv4Address(destination[0]).packed + struct.pack('!H', destination[1]))
    return sock


def trace(token):
    sock = ssl.create_default_context().wrap_socket(open_flow(token), server_hostname='one.one.one.one')
    try:
        sep = bytes([13, 10])
        sock.sendall(sep.join([b'GET /cdn-cgi/trace HTTP/1.1', b'Host: one.one.one.one',
                               b'Connection: close', b'', b'']))
        response = http.client.HTTPResponse(sock)
        response.begin()
        body = response.read(16384).decode('ascii')
        assert response.status == 200
        return dict(line.split('=', 1) for line in body.splitlines() if '=' in line)
    finally:
        sock.close()


def udp(token):
    transaction = secrets.token_bytes(12)
    packet = struct.pack('!HHI', 1, 0, 0x2112A442) + transaction
    with open_flow(token, STUN, udp=True) as sock:
        sock.sendall(bytes([0]) + ipaddress.IPv4Address(STUN[0]).packed +
                     struct.pack('!HH', STUN[1], len(packet)) + packet)
        assert exact(sock, 1) == bytes([0])
        assert str(ipaddress.IPv4Address(exact(sock, 4))) == STUN[0]
        assert struct.unpack('!H', exact(sock, 2))[0] == STUN[1]
        size = struct.unpack('!H', exact(sock, 2))[0]
        return stun_ip(exact(sock, size), transaction)


def expect_closed(token, destination=('1.1.1.1', 443)):
    with open_flow(token, destination) as sock:
        try:
            assert sock.recv(1) == b''
        except ConnectionResetError:
            pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', action='store_true')
    parser.add_argument('--expect-test-closed', action='store_true')
    parser.add_argument('--reference', action='store_true')
    args = parser.parse_args()
    if args.reference:
        transaction = secrets.token_bytes(12)
        packet = struct.pack('!HHI', 1, 0, 0x2112A442) + transaction
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BINDTODEVICE, b'CloudflareWARP' + bytes([0]))
            sock.settimeout(10)
            sock.sendto(packet, STUN)
            answer, peer = sock.recvfrom(2048)
            assert peer == STUN
        print(json.dumps({'udp_fingerprint': fingerprint(stun_ip(answer, transaction))}))
        return
    production = Path('/etc/flowd/token').read_bytes()
    result = trace(production)
    mapped = udp(production)
    reference = json.loads(subprocess.check_output(
        ['ip', 'netns', 'exec', 'warpns', 'python3', '-B', str(ROOT / 'flowd_probe.py'), '--reference']))
    assert result['warp'] == 'on' and result['ip'] != DIRECT
    assert mapped != DIRECT and fingerprint(mapped) == reference['udp_fingerprint']
    print(json.dumps({'kind': 'production-warp', 'ok': True, 'warp': result['warp'],
                      'udp_matches_bound_reference': True, 'udp_fingerprint': fingerprint(mapped)}))
    if args.test or args.expect_test_closed:
        test = (ROOT / 'test-token').read_bytes()
        expect_closed(secrets.token_bytes(16))
        expect_closed(test, ('127.0.0.1', 41924))
        if args.expect_test_closed:
            expect_closed(test)
            print(json.dumps({'kind': 'test-backend-down', 'ok': True, 'production_still_warp': True}))
        else:
            result = trace(test)
            mapped = udp(test)
            assert result['warp'] == 'off' and result['ip'] == DIRECT and mapped == DIRECT
            print(json.dumps({'kind': 'test-direct', 'ok': True, 'warp': 'off', 'ip': DIRECT,
                              'udp_transaction_checked': True, 'unknown_private_rejected': True}))


if __name__ == '__main__':
    main()
