"""Complete blocked resource screens on the already-approved working resolver pool."""
import asyncio
import json
import time

import matrix

DEADLINE = 1793385099  # Original 17:49:59Z + 2500-second experiment bound.


async def main():
    matrix.SINGLE = ['77.88.8.8']
    cases = []
    for workers in (112, 224):
        if time.time() >= DEADLINE:
            break
        cases.append(await matrix.compare('yandex-recovery-' + str(workers),
            ['77.88.8.8', '77.88.8.1'], workers, 'screen', 2))
    credible = [case for case in cases if case['credible']]
    confirmation = None
    reason = 'No complete Yandex multipath candidate won both matched screening pairs.'
    if credible:
        selected = max(credible, key=lambda case: case['candidate_download_Bps'])
        elapsed = []
        for case in cases:
            for row in matrix.read_rows(matrix.ROOT / (case['label'] + '-screen.jsonl')):
                if row['kind'] == 'window' and row.get('ok'):
                    elapsed.append(row['seconds'])
        needed = 12 * max(elapsed, default=90) + 60
        if DEADLINE - time.time() > needed:
            confirmation = await matrix.compare('selected-' + selected['label'], selected['endpoints'],
                                                  selected['workers'], 'confirm', 6)
            reason = 'Fresh matched confirmation after Google carrier became unavailable.'
        else:
            reason = 'Credible screen, but insufficient original time budget for six fresh pairs; not confirmed.'
    decision = dict(cases=cases, confirmation=confirmation, reason=reason, original_deadline=DEADLINE)
    (matrix.ROOT / 'recovery-decision.json').write_text(json.dumps(decision, indent=2))
    print(json.dumps(dict(kind='recovery-matrix-complete', confirmation=confirmation is not None,
                         reason=reason)), flush=True)


if __name__ == '__main__':
    asyncio.run(main())
